import libardrone
from time import sleep

def main():
	drone = libardrone.ARDrone()

	drone.takeoff()
	sleep(10)
	drone.move_forward()
	print 'moving forward'
	sleep(1.5)
	drone.hover()
	sleep(2)
	drone.move_left()
	print 'moving left'
	sleep(1.5)
	drone.hover()
	sleep(2)
	drone.move_backward()
	print 'moving backward'
	sleep(1.5)
	drone.hover()
	sleep(2)
	drone.move_right()
	print 'moving right'
	sleep(1.5)
	drone.hover()
	sleep(2)
	print 'twirling'
	drone.set_speed(0.8)
	drone.turn_left()
	sleep(1)
	drone.turn_left()
	sleep(1)
	drone.turn_left()
	sleep(1)
	drone.turn_left()
	sleep(1)
	drone.set_speed(0.2)
	drone.land()
	sleep(3)
	drone.halt()


if __name__ == '__main__':
	main()