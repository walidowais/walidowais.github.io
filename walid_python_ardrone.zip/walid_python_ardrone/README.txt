1. install batteries and power on ARDrone
2. connect to ARDrone Wifi network from computer
3. cd to folder in terminal
4. in terminal run "python walid_square.py"